create view cid3 as
select `hm49`.`tb_category`.`parent_id` AS `parent_id`
from `hm49`.`tb_category`
group by `hm49`.`tb_category`.`parent_id`;

-- comment on column cid3.parent_id not supported: 父类目id,顶级类目填0

